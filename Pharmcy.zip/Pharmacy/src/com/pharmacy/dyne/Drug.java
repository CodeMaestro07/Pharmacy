package com.pharmacy.dyne;

public class Drug {
	 private int drugId;
	    private String drugName;
	    private String usage;
	    private int stock;
	    private String expiryDate;

	    public Drug(int drugId, String drugName, String usage, int stock, String expiryDate) {
	        this.drugId = drugId;
	        this.drugName = drugName;
	        this.usage = usage;
	        this.stock = stock;
	        this.expiryDate = expiryDate;
	    }

	    public int getDrugId() {
	        return drugId;
	    }

	    @Override
	    public String toString() {
	        return "ID: " + drugId + ", Name: " + drugName + ", Usage: " + usage + ", Stock: " + stock + ", Expiry: " + expiryDate;
	    }
	}

