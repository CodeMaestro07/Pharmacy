package com.pharmacy.dyne;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class PharmacyManagementSystemGUI {

    private JFrame frame;
    private JTextField drugIdField, drugNameField, usageField, stockField, expiryField;
    private JTextArea displayArea;
    private ArrayList<Drug> drugs;

    public PharmacyManagementSystemGUI() {
        drugs = new ArrayList<>();
        createGUI();
    }

    private void createGUI() {
        // Frame setup
        frame = new JFrame("Pharmacy Management System");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        inputPanel.setBackground(new Color(204, 229, 255)); // Light blue background
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Input fields with labels
        JLabel drugIdLabel = new JLabel("Drug ID:");
        drugIdLabel.setForeground(new Color(0, 51, 102)); // Dark blue text
        drugIdField = new JTextField();

        JLabel drugNameLabel = new JLabel("Drug Name:");
        drugNameLabel.setForeground(new Color(0, 51, 102));
        drugNameField = new JTextField();

        JLabel usageLabel = new JLabel("Usage:");
        usageLabel.setForeground(new Color(0, 51, 102));
        usageField = new JTextField();

        JLabel stockLabel = new JLabel("Stock:");
        stockLabel.setForeground(new Color(0, 51, 102));
        stockField = new JTextField();

        JLabel expiryLabel = new JLabel("Expiry Date (yyyy-mm-dd):");
        expiryLabel.setForeground(new Color(0, 51, 102));
        expiryField = new JTextField();

        inputPanel.add(drugIdLabel);
        inputPanel.add(drugIdField);
        inputPanel.add(drugNameLabel);
        inputPanel.add(drugNameField);
        inputPanel.add(usageLabel);
        inputPanel.add(usageField);
        inputPanel.add(stockLabel);
        inputPanel.add(stockField);
        inputPanel.add(expiryLabel);
        inputPanel.add(expiryField);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(153, 204, 255)); // Medium blue background

        JButton addButton = new JButton("Add Drug");
        addButton.setBackground(new Color(0, 153, 76)); // Green background
        addButton.setForeground(Color.WHITE); // White text

        JButton displayButton = new JButton("Display Drugs");
        displayButton.setBackground(new Color(255, 153, 51)); // Orange background
        displayButton.setForeground(Color.WHITE);

        JButton deleteButton = new JButton("Delete Drug");
        deleteButton.setBackground(new Color(204, 0, 0)); // Red background
        deleteButton.setForeground(Color.WHITE);

        buttonPanel.add(addButton);
        buttonPanel.add(displayButton);
        buttonPanel.add(deleteButton);

        // Output Panel
        JPanel outputPanel = new JPanel();
        outputPanel.setBackground(new Color(255, 255, 204)); // Light yellow background

        displayArea = new JTextArea(10, 40);
        displayArea.setEditable(false);
        displayArea.setBackground(new Color(255, 255, 255)); // White background for the text area
        displayArea.setForeground(new Color(51, 51, 51)); // Dark grey text

        JScrollPane scrollPane = new JScrollPane(displayArea);
        outputPanel.add(scrollPane);

        // Add panels to the frame
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(outputPanel, BorderLayout.SOUTH);

        frame.setVisible(true);

        // Action Listeners
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addDrug();
            }
        });

        displayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayDrugs();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteDrug();
            }
        });
    }

    // Method to add a drug
    private void addDrug() {
        try {
            int id = Integer.parseInt(drugIdField.getText());
            String name = drugNameField.getText();
            String usage = usageField.getText();
            int stock = Integer.parseInt(stockField.getText());
            String expiry = expiryField.getText();
            Drug drug = new Drug(id, name, usage, stock, expiry);
            drugs.add(drug);
            clearFields();
            displayArea.setText("Drug added successfully!\n");
        } catch (Exception ex) {
            displayArea.setText("Error adding drug: " + ex.getMessage());
        }
    }

    // Method to display all drugs
    private void displayDrugs() {
        if (drugs.isEmpty()) {
            displayArea.setText("No drugs available.\n");
        } else {
            StringBuilder builder = new StringBuilder();
            for (Drug drug : drugs) {
                builder.append(drug).append("\n");
            }
            displayArea.setText(builder.toString());
        }
    }

    // Method to delete a drug
    private void deleteDrug() {
        try {
            int id = Integer.parseInt(drugIdField.getText());
            drugs.removeIf(drug -> drug.getDrugId() == id);
            clearFields();
            displayArea.setText("Drug deleted successfully!\n");
        } catch (Exception ex) {
            displayArea.setText("Error deleting drug: " + ex.getMessage());
        }
    }

    // Clear input fields
    private void clearFields() {
        drugIdField.setText("");
        drugNameField.setText("");
        usageField.setText("");
        stockField.setText("");
        expiryField.setText("");
    }

    public static void main(String[] args) {
        new PharmacyManagementSystemGUI();
    }
}
